Set Width x Height you'd like each image you select to become in the collage

# of Images Per Column will tell the program to create a new column each X number of images 

That's it thanks! 

//FamilyManP